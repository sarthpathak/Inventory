﻿namespace Inventory.Model
{
    public class ViewOrder
    {
        public string ProductName { get; set; }
        public int ProductQuantity { get; set; }
    }
}
