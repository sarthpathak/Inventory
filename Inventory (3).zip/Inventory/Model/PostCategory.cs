﻿namespace Inventory.Model
{
    public class PostCategory
    {
        public string Name { get; set; }
    }
}
