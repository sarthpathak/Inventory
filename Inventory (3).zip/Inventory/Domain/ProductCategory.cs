﻿using System.ComponentModel.DataAnnotations;

namespace Inventory.Domain
{
    public class ProductCategory:BaseDomain
    {
      
        public string Name { get; set; }
    }
}
