﻿namespace Inventory.Domain
{
    public class BaseDomain
    {
        public Guid Id { get; set; }
    }
}
