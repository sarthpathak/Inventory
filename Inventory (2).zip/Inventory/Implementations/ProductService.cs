﻿namespace Inventory.Implementations
{
    public class ProductService
    {
    }
}
