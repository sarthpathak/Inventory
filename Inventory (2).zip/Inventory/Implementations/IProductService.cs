﻿namespace Inventory.Implementations
{
    public interface IProductService
    {
    }
}