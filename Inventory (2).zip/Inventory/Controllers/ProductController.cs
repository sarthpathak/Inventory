﻿using Inventory.Domain;
using Inventory.DTO;
using Inventory.Reposits;
using Microsoft.AspNetCore.Mvc;

namespace Inventory.Controllers
{
    public class ProductController : Controller
    {

        private readonly IRepository<Product> _repository;

        public ProductController(IRepository<Product> repository)
        {
            _repository = repository;
        }

        [HttpPost]
        [Route("add")]
        public void AddProduct([FromBody] ViewProduct updatedProduct)
        {
            var Modelclass = new Product()
            {
                Name = updatedProduct.Name,
                Quantity = updatedProduct.Quantity,
                Measurement = updatedProduct.Measurement,
                CategoryId = updatedProduct.CategoryId,
            };

            _repository.Add(Modelclass);

        }
    }
}
