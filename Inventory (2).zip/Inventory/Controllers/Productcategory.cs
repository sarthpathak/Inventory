﻿using Microsoft.AspNetCore.Mvc;
using Inventory.Domain;
using System.Runtime.InteropServices;
using Inventory.Reposits;
using Inventory.DTO;

namespace Inventory.Controllers
{


    [ApiController]
    [Route("Api")]
    public class ProductCategory1 : Controller
    {

        private readonly IRepository<ProductCategory> Repository;

        public ProductCategory1(IRepository<ProductCategory> repository)
        {
            Repository = repository;
        }

        

        [HttpPost]
        [Route("Add/")]
        public IActionResult AddProduct([FromBody] ProductCategory updatedProduct)
        {
           

                Repository.Add(updatedProduct); 

                return Ok("Product updated successfully.");
           

        }

        [HttpGet]
        [Route("Get/{productId}")]
        public IActionResult GetProduct(int productId)
        {
            try
            {
                var product = Repository.GetById(productId);

                if (product == null)
                {
                    return NotFound($"Product with ID {productId} not found.");
                }

                return Ok(product);
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpDelete]
        [Route("Delete/{productId}")]
        public IActionResult DeleteProduct(int productId)
        {
            try
            {
                var product = Repository.GetById(productId);

                if (product == null)
                {
                    return NotFound($"Product with ID {productId} not found.");
                }

                Repository.Delete(product);

                return Ok($"Product with ID {productId} deleted successfully.");
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

       




        }

    }


    
    


        
