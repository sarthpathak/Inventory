﻿namespace Inventory.Model
{
    public class PostProductcs
    {
    }
}
