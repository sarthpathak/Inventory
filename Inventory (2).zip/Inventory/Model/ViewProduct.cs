﻿namespace Inventory.DTO


{
    public class ViewProduct
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Measurement { get; set; }
    }
}
