﻿namespace Inventory.Model
{
    public class ViewCustomer
    {
    }
}
