﻿using Inventory.Domain;

namespace Inventory.Controllers
{
    internal interface IProductService
    {
        object AddProduct(Product newProduct);
        object AddProduct(object newProduct);
    }
}