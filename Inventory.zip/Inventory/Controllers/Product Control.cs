﻿using Microsoft.AspNetCore.Mvc;
using Inventory.Domain;
using System.Runtime.InteropServices;
using Inventory.Reposits;

namespace Inventory.Controllers
{


    [ApiController]
    public class ProductController : Controller
    {

        private readonly IRepository<ProductCategory> Repository;

        public ProductController(IRepository<ProductCategory> repository)
        {
            Repository = repository;
        }


        [HttpPost]
        [Route("Add")]
        public IActionResult AddProduct([FromBody] ProductCategory updatedProduct)
        {
            try
            {
                if (updatedProduct == null)
                {
                    return BadRequest("Product data is null.");
                }

                Repository.Add(updatedProduct); 

                return Ok("Product updated successfully.");
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

        }
    }
}