﻿using System.ComponentModel.DataAnnotations;

namespace Inventory.Domain
{
    public class ProductCategory
    {
        [Key]
        public int CategoryId { get; set; }
        public string Name { get; set; }
    }
}
